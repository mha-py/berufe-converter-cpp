
Berufekonverter

Die männliche Berufsbezeichnung einfach eingeben und enter drücken, es erscheinen die
weiblich konvertierte Bezeichnung und eine Vorhersagewahrscheinlichkeit, letztere
gibt an, wie sehr das Netzwerk selbst glaubt, dass der Output korrekt ist. Evtl. kann
dieser Wert genutzt werden, um unzulässige Outputs herauszufiltern.



Was ganz gut funktioniert:
Krankenpfleger Onkologie
Technischer Zeichner
Geistlicher
Kaufmann
Ordendsbruder
Zimmerer
Sicherheitsbeauftragter
Psychologe, allgemeiner Psychologie
Tagesvater
Steward
Pflichtassistent (ärztlicher)
Stadtrat
Obstbauern

Wo es noch hakt:
Vergaser/Motor
Berufssport Motorboot